#!/usr/bin/env bash
# Called over SSH after uploading an allowlisted release and private env file.
set -euo pipefail
stage="$1"
release="$2"
[[ "$stage" == /home/ubuntu/.cache/voxel-* && "$release" =~ ^[0-9]{8}-[0-9]{6}$ ]] || exit 2
base=/opt/voxel-kingdom
version="$base/releases/$release"
export DEBIAN_FRONTEND=noninteractive
if ! dpkg-query -W -f='${Status}' python3-venv 2>/dev/null | grep -q 'install ok installed'; then
    apt-get update -qq
    apt-get install -y -qq python3-venv
fi
id voxel-kingdom >/dev/null 2>&1 || useradd --system --home-dir /var/lib/voxel-kingdom --shell /usr/sbin/nologin voxel-kingdom
install -d -o voxel-kingdom -g voxel-kingdom -m 700 /var/lib/voxel-kingdom
install -d -o root -g voxel-kingdom -m 750 /etc/voxel-kingdom
install -d -o root -g root -m 700 /etc/voxel-kingdom/tls
install -d -m 755 "$version"
tar --no-same-owner -xzf "$stage/release.tar.gz" -C "$version"
chmod -R a+rX "$version"
test -x "$base/venv/bin/python" || python3 -m venv "$base/venv"
"$base/venv/bin/python" -m pip install --disable-pip-version-check -r "$version/backend/requirements.txt"
install -o root -g voxel-kingdom -m 640 "$stage/server.env" /etc/voxel-kingdom/server.env
if [ ! -f /etc/voxel-kingdom/tls/server.crt ]; then
    openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 365 \
      -keyout /etc/voxel-kingdom/tls/server.key -out /etc/voxel-kingdom/tls/server.crt \
      -subj '/CN=140.143.163.231' -addext 'subjectAltName=IP:140.143.163.231' >/dev/null 2>&1
    chmod 600 /etc/voxel-kingdom/tls/server.key
fi
# Preserve prior release pointer for manual rollback; never remove application data.
if [ -L "$base/current" ]; then readlink "$base/current" > "$base/previous-release"; fi
ln -sfn "$version" "$base/current"
install -m 644 "$version/deploy/voxel-kingdom.service" /etc/systemd/system/
install -m 644 "$version/deploy/voxel-kingdom-backup.service" /etc/systemd/system/
install -m 644 "$version/deploy/voxel-kingdom-backup.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable voxel-kingdom.service
systemctl restart voxel-kingdom.service
for attempt in $(seq 1 30); do
    if curl -fsS http://127.0.0.1:8765/api/health >/dev/null; then break; fi
    sleep 1
done
curl -fsS http://127.0.0.1:8765/api/health
install -m 644 "$version/deploy/nginx-ip.conf" /etc/nginx/sites-available/voxel-kingdom
ln -sfn /etc/nginx/sites-available/voxel-kingdom /etc/nginx/sites-enabled/voxel-kingdom
if ! nginx -t; then
    unlink /etc/nginx/sites-enabled/voxel-kingdom
    echo 'Nginx validation failed; existing Nginx was NOT reloaded.' >&2
    exit 1
fi
systemctl reload nginx
systemctl enable --now voxel-kingdom-backup.timer
systemctl start voxel-kingdom-backup.service
curl --cacert /etc/voxel-kingdom/tls/server.crt --resolve 140.143.163.231:443:127.0.0.1 -fsS https://140.143.163.231/api/health
printf '\nExisting site HTTP: '
curl --resolve api.patelender.cn:443:127.0.0.1 -s -o /dev/null -w '%{http_code}\n' https://api.patelender.cn/
openssl x509 -in /etc/voxel-kingdom/tls/server.crt -noout -fingerprint -sha256 -dates
systemctl show voxel-kingdom.service -p ActiveState -p MemoryCurrent -p MainPID
